/* ALL EDITABLE CONTENT LIVES HERE (same structure as before). Save + refresh. */
const proj = (id, title, tone, more = {}) => ({
  id, title, tone, role: "Your role", year: "2026",
  summary: "One sentence about the problem and what you designed.",
  image: "", imageAlt: "", url: "", /* url blank = built-in write-up */
  tags: ["Product design", "UX research"],
  writeup: {
    overview: "Introduce the project and your contribution.",
    problem: "Describe the starting point and the people involved.",
    process: "Explain your research, design decisions, and iterations.",
    outcome: "Share the result, evidence, lessons, and next steps.",
    images: [] /* [{src:"assets/images/x.png", alt:"", caption:""}] */
  },
  ...more
});

window.SKETCHBOOK = {
  stickerDir: "assets/icons/stickers",
  game: ["buttercup", "rose-anemone", "coral-flower", "crimson-daisy"],
  artwork: { works: ["ochre-flower", "rose-anemone", "burgundy-bloom"], passions: ["botanical-pair", "buttercup"] },
  profile: {
    name: "Khloe Sakai",
    year: "2026",
    eyebrow: "product design & ui/ux",
    tagline: "Thoughtful experiences, made with a",
    accent: "little heart.",
    intro: "i study information technology & web science and communications, media & design at rensselaer, with a minor in marketing. i love talking to people, untangling complicated things, and making them feel friendly. (rewrite this in your own words!)",
    photo: "", photoAlt: "A portrait of Khloe",
    email: "khloekjs@gmail.com", linkedin: "linkedin.com/in/khloe-sakai",
    school: "Rensselaer Polytechnic Institute",
    degree: "B.S. Dual: Information Technology & Web Science / Communications, Media & Design",
    minor: "Marketing", dates: "Aug 2025 – May 2029 (expected)",
    skills: ["Visual & UI/UX design", "Low to high fidelity prototyping", "Figma", "Photoshop & Illustrator", "HTML / CSS / JavaScript", "Python, SQL, C#, Unity"]
  },
  leadership: [
    { role: "Co-Founder", org: "Independent Project · gaming creator community" },
    { role: "Work Party Manager", org: "Alpha Gamma Delta" },
    { role: "General Board Member", org: "Philippine American League" },
    { role: "General Board Member", org: "Club Water Polo" },
    { role: "Marketing Lead", org: "School Club · 2022–2025" }
  ],
  works: [proj("work-one", "Work title one", "peach"), proj("work-two", "Work title two", "rose"), proj("work-three", "Work title three", "sand")],
  passions: [proj("passion-one", "Passion project one", "rose", { featured: true }), proj("passion-two", "Passion project two", "sand", { featured: true })]
};
