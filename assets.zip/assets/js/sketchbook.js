(() => {
const D = window.SKETCHBOOK, P = D.profile, B = document.body;
const EL = n => `assets/icons/elements/${n}.png`, ST = n => `${D.stickerDir}/${n}.png`;
const W = (vw, vh, min = 90) => `min(max(${vw}vw,${min}px),${vh}vh)`;
const $ = (t, a = {}, ...k) => {
  const e = document.createElement(t);
  for (const [x, v] of Object.entries(a)) {
    if (v == null || v === false) continue;
    if (x === 'class') e.className = v; else if (x === 'style') e.style.cssText = v;
    else if (x.startsWith('on')) e.addEventListener(x.slice(2), v); else e.setAttribute(x, v);
  }
  e.append(...k.flat().filter(c => c != null && c !== false)); return e;
};
/* sticker: [src, left, top, width, rotation, class, [mobileLeft, mobileTop]] */
const stk = ([src, x, y, w, r = 0, c = '', m]) => $('img', { class: 'stk ' + c, src, alt: '', 'aria-hidden': 'true',
  style: `--x:${x};--y:${y};--w:${w};--r:${r}deg;` + (m ? `--mx:${m[0]};--my:${m[1]};` : '') });
const flow = (id, cls, S, ...k) => $('section', { class: `page flow ${cls}`, id }, S.map(stk), $('div', { class: 'row' }, ...k));
const head = (t, s) => $('div', { class: 'head' }, $('h2', { class: 'serif' }, t), $('p', { class: 'hand' }, s));
const dlg = $('dialog', { id: 'wu' });
const isRec = () => B.classList.contains('recruiter');
let cur = 'home';

function openProject(p) {
  if (p.url) { /^https?:/.test(p.url) ? window.open(p.url, '_blank', 'noopener') : (location.href = p.url); return; }
  location.hash = (isRec() ? 'recruiter/' : '') + 'project/' + p.id;
}
function card(p, i, kind) {
  const names = D.artwork[kind];
  const ph = () => $('div', { class: 'ph ' + (p.tone || 'peach') }, $('img', { src: ST(p.sticker || names[i % names.length]), alt: '' }), $('span', { class: 'hand' }, 'cover image goes here'));
  const media = p.image ? $('img', { class: 'cover', src: p.image, alt: p.imageAlt || '', onerror: ev => ev.target.replaceWith(ph()) }) : ph();
  return $('article', { class: 'card' + (kind === 'passions' ? ' pol' : '') }, media,
    $('div', { class: 'ct' }, $('h3', { class: 'serif' }, p.title), $('p', { class: 'meta hand' }, `${p.role} · ${p.year}`),
      $('p', { class: 'sum' }, p.summary), $('p', { class: 'tags' }, (p.tags || []).map(t => $('span', {}, t))),
      $('button', { class: 'go hand', onclick: () => openProject(p) }, 'read the write-up →')));
}
function openWU(p) {
  const w = p.writeup || {};
  dlg.replaceChildren($('button', { class: 'x hand', onclick: () => dlg.close() }, 'close ✕'),
    $('p', { class: 'meta hand' }, `${p.role} · ${p.year}`), $('h2', { class: 'serif' }, p.title),
    ...[['overview', 'overview'], ['problem', 'the problem'], ['process', 'the process'], ['outcome', 'the outcome']]
      .map(([k, l]) => w[k] ? [$('h3', { class: 'hand' }, l), $('p', { class: 'wt' }, w[k])] : null),
    ...(w.images || []).map(im => $('figure', {}, $('img', { src: im.src, alt: im.alt || '' }), im.caption ? $('figcaption', { class: 'hand' }, im.caption) : null)));
  if (!dlg.open) dlg.showModal();
}
dlg.addEventListener('close', () => { if (location.hash.includes('project/')) history.replaceState(null, '', isRec() ? '#recruiter' : '#' + cur); });

/* ---- pages ---- */
const hero = $('section', { class: 'page hero', id: 'home' }, [
  [EL('orange-wash'), '38%', '-10%', W(58, 92, 300), 0, 'wash', ['-20%', '38%']],
  [EL('rose-wash'), '62%', '38%', W(44, 70, 260), 0, 'wash', ['30%', '58%']],
  [ST('coral-flower'), '56%', '12%', W(30, 46, 150), -8, 'sway', ['6%', '54%']],
  [EL('violet-pansy'), '79%', '50%', W(20, 32, 110), 10, 'sway', ['58%', '62%']],
  [EL('orange-bloom'), '76%', '2%', W(17, 26, 100), 14, 'sway', ['64%', '42%']],
  [EL('gold-stars'), '50%', '64%', W(12, 18, 80), 0, '', ['66%', '80%']],
  [EL('paper-plane'), '40%', '74%', W(12, 17, 90), -6, 'nomob'],
  [EL('pressed-wildflower'), '92%', '30%', W(8, 24, 60), 6, 'nomob'],
  [EL('pink-blossoms'), '22%', '66%', W(9, 26, 60), -10, '', ['40%', '78%']],
  [EL('swirl-arrow'), '34%', '76%', W(7, 16, 50), 0, 'nomob']].map(stk),
  $('div', { class: 'stamp hand' }, P.year),
  $('div', { class: 'hero-copy' }, $('p', { class: 'label hand' }, P.eyebrow),
    $('h1', { class: 'serif' }, P.tagline + ' ', $('span', { class: 'u' }, P.accent)),
    $('p', { class: 'cue hand' }, 'flip through the pages →')));

const works = flow('works', 'dots', [
  [EL('blush-smear'), '-4%', '60%', W(40, 60, 240), 0, 'wash'], [EL('yellow-splatter'), '55%', '-12%', W(34, 56, 220), 0, 'wash'],
  [EL('olive-sprig'), '3%', '6%', W(7, 20, 60), -8], [EL('blue-dashes'), '16%', '72%', W(8, 16, 60), -10],
  [EL('gold-stars'), '30%', '8%', W(7, 12, 50)], [ST('buttercup'), '86%', '76%', W(10, 18, 70), 14]],
  head('my works', 'things i made & loved'), ...D.works.map((p, i) => card(p, i, 'works')));

const passion = flow('passion', 'lined', [
  [EL('pink-haze'), '-5%', '10%', W(50, 70, 260), 0, 'wash'], [EL('pink-buds'), '2%', '52%', W(7, 26, 50), -4],
  [EL('navy-hearts'), '44%', '4%', W(8, 16, 60), 8], [EL('leaf-sprig'), '90%', '58%', W(9, 26, 60), -6], [EL('magenta-bloom'), '72%', '2%', W(10, 20, 70), 12]],
  head('passion projects', 'made just because'), ...D.passions.map((p, i) => card(p, i, 'passions')));

const photo = $('div', { class: 'pw' }, P.photo ? $('img', { class: 'photo', src: P.photo, alt: P.photoAlt }) :
  $('div', { class: 'photo ph2' }, $('img', { src: ST('coral-flower'), alt: '' }), $('span', { class: 'hand' }, 'your photo goes here')));
const abt = $('div', { class: 'abt' }, $('h2', { class: 'serif' }, "hi, i'm ", $('span', { class: 'u' }, 'khloe!')),
  $('div', { class: 'card intro' }, $('p', {}, P.intro)),
  $('p', { class: 'links' }, $('a', { class: 'lnk hand', href: 'mailto:' + P.email }, 'say hello'),
    $('a', { class: 'lnk hand', href: 'https://' + P.linkedin, target: '_blank', rel: 'noopener' }, 'linkedin ↗')));
const about = $('div', { class: 'grp', id: 'about' },
  flow(null, 'kraft', [[EL('orange-wash'), '-6%', '50%', W(40, 60, 240), 0, 'wash'], [EL('violet-pansy'), '46%', '72%', W(11, 20, 70), -10],
    [EL('pink-blossoms'), '94%', '12%', W(8, 26, 60), 6], [EL('paper-plane'), '60%', '4%', W(9, 14, 60), 6]], photo, abt),
  flow(null, 'dots', [[EL('pink-haze'), '60%', '55%', W(40, 60, 240), 0, 'wash'], [EL('down-arrows'), '40%', '3%', W(8, 14, 60)],
    [EL('pressed-wildflower'), '93%', '8%', W(8, 26, 60), 5], [EL('double-exclaim'), '70%', '78%', W(6, 14, 50), 8]],
    $('article', { class: 'card' }, $('h3', { class: 'hand' }, 'school'), $('p', { class: 'serif big' }, P.school), $('p', {}, P.degree), $('p', {}, 'Minor: ' + P.minor), $('p', { class: 'meta hand' }, P.dates)),
    $('div', { class: 'lead' }, $('h3', { class: 'hand' }, 'leadership'), $('div', { class: 'notes' }, D.leadership.map(l => $('div', { class: 'sn' }, $('b', { class: 'hand' }, l.role), $('span', {}, l.org))))),
    $('article', { class: 'card' }, $('h3', { class: 'hand' }, 'things i use'), $('p', { class: 'chips' }, P.skills.map(s => $('span', {}, s))))));

function game() {
  const names = D.game; let first = null, lock = false, moves = 0, matched = 0;
  const board = $('div', { class: 'board' }), mv = $('span', {}, '0'), msg = $('p', { class: 'win hand' });
  const flip = (b, n) => {
    if (lock || b.classList.contains('up')) return; b.classList.add('up');
    if (!first) { first = { b, n }; return; }
    mv.textContent = ++moves;
    if (first.n === n) { first.b.classList.add('ok'); b.classList.add('ok'); first = null; if (++matched === names.length) msg.textContent = `all matched in ${moves} moves!`; }
    else { lock = true; const a = first.b; first = null; setTimeout(() => { a.classList.remove('up'); b.classList.remove('up'); lock = false; }, 800); }
  };
  const deal = () => {
    first = null; lock = false; moves = 0; matched = 0; mv.textContent = '0'; msg.textContent = '';
    board.replaceChildren(...[...names, ...names].sort(() => Math.random() - .5).map(n =>
      $('button', { class: 'gc', 'aria-label': 'flower card', onclick: ev => flip(ev.currentTarget, n) }, $('img', { src: ST(n), alt: n.replace(/-/g, ' ') }))));
  };
  deal();
  return $('section', { class: 'page play', id: 'play' }, [
    [EL('gold-stars'), '8%', '16%', W(9, 14, 60)], [EL('music-notes'), '80%', '12%', W(9, 16, 60), 6], [EL('orange-poppy'), '3%', '62%', W(11, 20, 70), -12],
    [EL('double-exclaim'), '88%', '70%', W(7, 16, 50), 8], [EL('rose-wash'), '38%', '45%', W(40, 60, 240), 0, 'wash']].map(stk),
    $('div', { class: 'pcol' }, $('h2', { class: 'serif' }, 'a little game'), $('p', { class: 'hand status' }, 'match the flowers · moves: ', mv), board, msg,
      $('button', { class: 'go hand', onclick: deal }, 'play again')));
}
const play = game();

/* ---- chrome ---- */
const NAV = [['works', 'works'], ['passion', 'passion projects'], ['about', 'about me'], ['play', 'play']], IDS = ['home', 'works', 'passion', 'about', 'play'];
const track = $('div', { id: 'track' }, hero, works, passion, about, play);
const goTo = id => {
  const s = document.getElementById(id); if (!s) return;
  if (isRec()) { location.hash = id; return; }
  track.scrollTo({ left: s.offsetLeft, behavior: 'smooth' }); history.replaceState(null, '', '#' + id);
};
const hd = $('header', { id: 'hd' }, $('button', { class: 'wm hand', onclick: () => goTo('home') }, $('img', { src: ST('coral-flower'), alt: '' }), "khloe's portfolio"),
  $('nav', {}, NAV.map(([id, l]) => $('button', { class: 'nl hand', 'data-id': id, onclick: () => goTo(id) }, l))),
  $('button', { class: 'rb hand', id: 'rb', onclick: () => { location.hash = isRec() ? 'home' : 'recruiter'; } }, 'recruiter mode'));
const by = d => $('button', { class: 'ar hand', 'aria-label': d < 0 ? 'previous' : 'next', onclick: () => track.scrollBy({ left: d * innerWidth * .9, behavior: 'smooth' }) }, d < 0 ? '←' : '→');
const arrows = $('div', { class: 'arrows' }, by(-1), by(1));

const rs = (t, ...k) => $('section', { class: 'rs' }, $('h2', { class: 'hand' }, t), ...k);
const ri = p => $('div', { class: 'ri' }, $('h3', {}, p.title), $('p', { class: 'meta' }, `${p.role} · ${p.year}`), $('p', {}, p.summary), $('button', { class: 'go hand', onclick: () => openProject(p) }, 'read the write-up →'));
const rec = $('main', { id: 'rec' }, $('div', { class: 'rpage' },
  $('h1', { class: 'serif' }, P.name), $('p', { class: 'hand' }, `${P.eyebrow} · ${P.year}`),
  $('p', {}, P.email, ' · ', P.linkedin),
  rs('education', $('p', {}, $('b', {}, P.school)), $('p', {}, P.degree + '. Minor: ' + P.minor), $('p', { class: 'meta' }, P.dates)),
  rs('leadership', ...D.leadership.map(l => $('p', {}, $('b', {}, l.role), ' · ' + l.org))),
  rs('works', ...D.works.map(ri)),
  rs('passion projects', ...D.passions.filter(p => p.featured !== false).map(ri)),
  rs('skills', $('p', {}, P.skills.join(' · '))),
  $('button', { class: 'go hand noprint', onclick: () => print() }, 'print / save pdf')));

const mark = () => {
  const x = track.scrollLeft + innerWidth * .4; cur = 'home';
  IDS.forEach(i => { if (document.getElementById(i).offsetLeft <= x) cur = i; });
  document.querySelectorAll('.nl').forEach(b => b.classList.toggle('on', b.dataset.id === cur));
};
track.addEventListener('scroll', () => requestAnimationFrame(mark), { passive: true });
track.addEventListener('wheel', e => { if (Math.abs(e.deltaY) > Math.abs(e.deltaX)) { e.preventDefault(); track.scrollBy({ left: e.deltaY, behavior: 'instant' }); } }, { passive: false });
addEventListener('keydown', e => {
  if (dlg.open || isRec() || e.altKey || e.ctrlKey || e.metaKey || /^(INPUT|BUTTON|A|TEXTAREA|SELECT)$/.test(e.target.tagName)) return;
  if (e.key === 'ArrowRight') track.scrollBy({ left: innerWidth * .9, behavior: 'smooth' });
  if (e.key === 'ArrowLeft') track.scrollBy({ left: -innerWidth * .9, behavior: 'smooth' });
});

function route() {
  const p = location.hash.slice(1).split('/'), r = p[0] === 'recruiter', rest = r ? p.slice(1) : p;
  B.classList.toggle('recruiter', r); document.getElementById('rb').textContent = r ? 'back to sketchbook' : 'recruiter mode';
  if (rest[0] === 'project') {
    const pr = [...D.works, ...D.passions].find(x => x.id === rest[1]);
    if (pr) { openWU(pr); return; }
    history.replaceState(null, '', r ? '#recruiter' : '#home'); if (dlg.open) dlg.close(); return;
  }
  if (dlg.open) dlg.close();
  const s = !r && document.getElementById(rest[0] || 'home'); if (s) track.scrollTo({ left: s.offsetLeft });
}
document.getElementById('app').append(hd, track, arrows, rec, dlg);
addEventListener('hashchange', route); route(); mark();
})();
